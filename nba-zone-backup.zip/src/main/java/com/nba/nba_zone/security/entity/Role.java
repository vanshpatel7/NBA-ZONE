package com.nba.nba_zone.security.entity;

public enum Role {
    USER,
    ADMIN
}
