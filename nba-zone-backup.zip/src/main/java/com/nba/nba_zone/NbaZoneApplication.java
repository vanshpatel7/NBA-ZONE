package com.nba.nba_zone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NbaZoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(NbaZoneApplication.class, args);
	}

}
