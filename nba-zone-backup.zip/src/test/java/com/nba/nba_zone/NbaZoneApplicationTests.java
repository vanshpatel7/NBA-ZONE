package com.nba.nba_zone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NbaZoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
